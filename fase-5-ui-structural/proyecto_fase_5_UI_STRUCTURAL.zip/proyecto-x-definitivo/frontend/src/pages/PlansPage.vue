<template>
  <div class="stack">
    <div class="card">
      <div style="font-weight: 650">Planes</div>
      <div class="muted" style="font-size: 12px; margin-top: 6px">
        Placeholder (offline). Aquí luego vendrán los tiers.
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <div style="font-weight: 650">Free</div>
        <div class="muted" style="font-size: 12px; margin-top: 6px">Buscar + guardar + publicar básico.</div>
      </div>
      <div class="card">
        <div style="font-weight: 650">Pro</div>
        <div class="muted" style="font-size: 12px; margin-top: 6px">Import/Export + pipeline avanzado.</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

@media (max-width: 900px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>
