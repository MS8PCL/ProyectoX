<template>
  <div class="stack">
    <div class="card">
      <div style="font-weight: 650">Proceso de Selección</div>
      <div class="muted" style="font-size: 12px; margin-top: 6px">
        Flujo empresa: nuevo / revisar / entrevista / oferta / descartado.
      </div>
    </div>

    <div v-if="app.role !== 'empresa'" class="card muted">Cambia a rol empresa para usar esta sección.</div>

    <div v-else class="stack">
      <div v-if="!companyListings.length" class="card muted">(vacío) — crea un anuncio en Publicar.</div>

      <div v-for="l in companyListings" :key="l.id" class="card">
        <button class="accHead" type="button" @click="toggleOpen(l.id)">
          <div>
            <div style="font-weight: 650">{{ l.title }}</div>
            <div class="muted" style="font-size: 12px; margin-top: 6px">{{ l.company }} · {{ l.location }} · {{ l.pay }}</div>
          </div>
          <div class="row" style="gap: 10px; justify-content: flex-end; align-items: center">
            <span class="kbd">{{ countByListing[l.id] || 0 }} candidatos</span>
            <span class="kbd">{{ openListingId === l.id ? '—' : '+' }}</span>
          </div>
        </button>

        <div v-if="openListingId === l.id" class="accBody">
          <div class="row" style="justify-content: space-between; align-items: center">
            <div class="muted" style="font-size: 12px">Arrastra candidatos entre etapas. (Aplicantes entran en "nuevo" automáticamente.)</div>
            <button class="btn" @click="app.openDrawer(l.id)">Ver anuncio</button>
          </div>

          <div class="cols" style="margin-top: 10px">
            <div
              v-for="s in stages"
              :key="s"
              class="col"
              :data-dnd="drag.listingId === l.id && !!drag.rowId"
              :data-over="over.listingId === l.id && over.stage === s"
              @dragenter.prevent="onDragEnter(l.id, s)"
              @dragover.prevent
              @dragleave="onDragLeave(l.id, s)"
              @drop.prevent="onDrop(l.id, s)"
            >
              <div class="colHead">{{ stageLabel[s] || s }}</div>
              <div class="stack" style="gap: 8px">
                <div
                  v-for="c in candidatesByStage(l.id)[s]"
                  :key="c.id"
                  class="cand"
                  :data-dragging="drag.listingId === l.id && drag.rowId === c.id"
                  @click="openCandidate(c)"
                >
                  <div class="row" style="justify-content: space-between; align-items: center">
                    <div class="row" style="gap: 10px; align-items: center">
                      <button
                        class="dragHandle"
                        type="button"
                        draggable="true"
                        aria-label="Arrastrar"
                        title="Arrastrar"
                        @click.stop
                        @dragstart="onDragStart(l.id, c.id, s, $event)"
                        @dragend="onDragEnd"
                      >
                        <span class="hand" aria-hidden="true" />
                      </button>
                      <div>
                        <div style="font-weight: 650">{{ c.name || '—' }}</div>
                        <div v-if="candidateTitle(c)" class="muted" style="font-size: 12px; margin-top: 4px">{{ candidateTitle(c) }}</div>
                      </div>
                    </div>
                    <div class="row" style="gap: 8px">
                      <button class="btn" type="button" @click.stop="toggleActions(l.id, c.id)">Acciones</button>
                    </div>
                  </div>

                  <div class="notes">
                    <button
                      v-if="!(notesUi.open && notesUi.listingId === l.id && notesUi.rowId === c.id)"
                      class="notesPreview"
                      type="button"
                      @click.stop="openNotes(l.id, c.id)"
                    >
                      <span class="muted">Notas:</span>
                      <span class="muted">{{ notesPreview(c.notes) }}</span>
                    </button>

                    <textarea
                      v-else
                      class="textarea"
                      :value="c.notes || ''"
                      placeholder="Notas..."
                      @click.stop
                      @input="(e) => app.setSelectionNotes(l.id, c.id, e.target.value)"
                      @blur="closeNotes()"
                    />
                  </div>

                  <div v-if="actionsUi.open && actionsUi.listingId === l.id && actionsUi.rowId === c.id" class="actionsPanel">
                    <div class="row" style="gap: 8px; flex-wrap: wrap">
                      <button class="btn" type="button" :disabled="!cvUrlFor(c)" @click.stop="openCv(c)">Ver CV</button>
                      <button class="btn" type="button" @click.stop="toggleListPanel(l.id, c.id)">Añadir a lista</button>
                      <button class="btn" type="button" @click.stop="toggleMoveMenu(l.id, c.id)">Mover a…</button>
                    </div>

                    <div v-if="moveUi.open && moveUi.listingId === l.id && moveUi.rowId === c.id" class="movePanel">
                      <div class="muted" style="font-size: 12px; margin-bottom: 6px">Mover a etapa</div>
                      <div class="row" style="gap: 8px; flex-wrap: wrap">
                        <button v-for="st in stages" :key="st" class="btn" type="button" @click.stop="moveToStage(l.id, c.id, st)">
                          {{ stageLabel[st] || st }}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div v-if="listUi.open && listUi.listingId === l.id && listUi.rowId === c.id" class="listPanel">
                    <div class="row" style="gap: 8px; flex-wrap: wrap">
                      <select class="select" v-model="listUi.listId" style="min-width: 220px">
                        <option v-for="li in app.lists" :key="li.id" :value="li.id">{{ li.name }}</option>
                      </select>
                      <input class="input" v-model="listUi.newName" placeholder="Crear lista…" style="min-width: 220px" />
                      <button class="btn primary" type="button" :disabled="!listUi.listId && !listUi.newName.trim()" @click.stop="addToSelectedList(c)">Añadir</button>
                      <button class="btn" type="button" @click.stop="closeListPanel()">Cerrar</button>
                    </div>
                    <div v-if="!app.lists.length" class="muted" style="font-size: 12px; margin-top: 8px">No hay listas. Escribe un nombre y crea una.</div>
                  </div>
                </div>

                <div v-if="!candidatesByStage(l.id)[s].length" class="muted" style="font-size: 12px">
                  <span v-if="drag.listingId === l.id && drag.rowId">Suelta aquí</span>
                  <span v-else>(vacío)</span>
                </div>
              </div>
            </div>
          </div>

          <div class="muted" style="font-size: 12px; margin-top: 10px">Tip: guarda candidatos en Listas para futuras vacantes (no los saca del proceso).</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useAppStore } from '../stores/app.js'

const route = useRoute()
const app = useAppStore()
app.bootstrap()

const stages = ['nuevo', 'revisar', 'entrevista', 'oferta', 'descartado']
const stageLabel = {
  nuevo: 'Nuevo',
  revisar: 'Revisión',
  entrevista: 'Entrevista',
  oferta: 'Oferta',
  descartado: 'Descartado',
}

const companyListings = computed(() => (app.listings || []).filter((l) => l.createdBy === 'empresa' && l.kind === 'empleo'))

const countByListing = computed(() => {
  const out = {}
  for (const l of companyListings.value) {
    const list = app.state?.pipeline?.[l.id]
    out[l.id] = Array.isArray(list) ? list.length : 0
  }
  return out
})

const openListingId = ref('')

const listUi = reactive({ listingId: '', rowId: '', open: false, listId: '', newName: '' })
const actionsUi = reactive({ listingId: '', rowId: '', open: false })
const notesUi = reactive({ listingId: '', rowId: '', open: false })

function pickInitialOpen() {
  const q = route.query?.listingId
  const qid = typeof q === 'string' ? q : ''
  const exists = qid && companyListings.value.some((l) => l.id === qid)
  if (exists) return qid
  return companyListings.value[0]?.id || ''
}

watch(
  () => [companyListings.value.length, route.query?.listingId],
  () => {
    if (!openListingId.value) openListingId.value = pickInitialOpen()
    else {
      // if current open listing disappears, fallback
      const ok = companyListings.value.some((l) => l.id === openListingId.value)
      if (!ok) openListingId.value = pickInitialOpen()

      // if URL requests a listing, honor it
      const q = route.query?.listingId
      const qid = typeof q === 'string' ? q : ''
      if (qid && companyListings.value.some((l) => l.id === qid)) openListingId.value = qid
    }
  },
  { immediate: true }
)

function toggleOpen(listingId) {
  openListingId.value = openListingId.value === listingId ? '' : listingId
}

function getCandidates(listingId) {
  const list = app.state?.pipeline?.[listingId]
  return Array.isArray(list) ? list : []
}

function candidatesByStage(listingId) {
  const map = Object.fromEntries(stages.map((s) => [s, []]))
  for (const c of getCandidates(listingId)) map[c.stage]?.push(c)
  return map
}

function closeListPanel() {
  listUi.open = false
  listUi.listingId = ''
  listUi.rowId = ''
  listUi.listId = ''
  listUi.newName = ''
}

function toggleActions(listingId, rowId) {
  if (actionsUi.open && actionsUi.listingId === listingId && actionsUi.rowId === rowId) return closeActions()
  actionsUi.open = true
  actionsUi.listingId = listingId
  actionsUi.rowId = rowId
  // close other panels
  moveUi.open = false
  listUi.open = false
}

function closeActions() {
  actionsUi.open = false
  actionsUi.listingId = ''
  actionsUi.rowId = ''
  moveUi.open = false
}

const moveUi = reactive({ listingId: '', rowId: '', open: false })

function toggleMoveMenu(listingId, rowId) {
  if (moveUi.open && moveUi.listingId === listingId && moveUi.rowId === rowId) {
    moveUi.open = false
    moveUi.listingId = ''
    moveUi.rowId = ''
    return
  }
  moveUi.open = true
  moveUi.listingId = listingId
  moveUi.rowId = rowId
}

function moveToStage(listingId, rowId, stage) {
  app.moveCandidate(listingId, rowId, stage)
  app.toast = { kind: 'ok', text: `Movido a: ${stageLabel[stage] || stage}` }
  closeActions()
}

function notesPreview(notes) {
  const t = String(notes || '').trim()
  if (!t) return '(sin notas)'
  const one = t.split(/\r?\n/)[0]
  return one.length > 60 ? one.slice(0, 60) + '…' : one
}

function openNotes(listingId, rowId) {
  notesUi.open = true
  notesUi.listingId = listingId
  notesUi.rowId = rowId
}

function closeNotes() {
  notesUi.open = false
  notesUi.listingId = ''
  notesUi.rowId = ''
}

function toggleListPanel(listingId, rowId) {
  if (listUi.open && listUi.listingId === listingId && listUi.rowId === rowId) {
    closeListPanel()
    return
  }
  listUi.open = true
  listUi.listingId = listingId
  listUi.rowId = rowId
  listUi.listId = app.lists?.[0]?.id || ''
  listUi.newName = ''
}

function addToSelectedList(row) {
  const cid = row?.candidateId
  if (!cid) {
    app.toast = { kind: 'info', text: 'Este candidato no tiene ID (demo).'}
    return
  }

  // If user typed a new list name, create it (or reuse existing if already present)
  const proposed = String(listUi.newName || '').trim()
  if (proposed) {
    const created = app.createList(proposed)
    if (created) {
      listUi.listId = created.id
    } else {
      const existing = (app.lists || []).find((l) => String(l.name).toLowerCase() === proposed.toLowerCase())
      if (existing) listUi.listId = existing.id
    }
    listUi.newName = ''
  }

  if (!listUi.listId) {
    app.toast = { kind: 'info', text: 'Elige una lista o escribe un nombre para crearla.' }
    return
  }

  app.addCandidateToList(listUi.listId, cid)
  closeListPanel()
}

// drag & drop
const drag = reactive({ listingId: '', rowId: '', fromStage: '' })
const over = reactive({ listingId: '', stage: '' })

function onDragStart(listingId, rowId, stage, ev) {
  drag.listingId = listingId
  drag.rowId = rowId
  drag.fromStage = stage

  // Needed in some browsers to initiate DnD
  try {
    if (ev?.dataTransfer) {
      ev.dataTransfer.effectAllowed = 'move'
      ev.dataTransfer.setData('text/plain', `${listingId}:${rowId}`)
    }
  } catch {
    // ignore
  }
}

function onDragEnd() {
  drag.listingId = ''
  drag.rowId = ''
  drag.fromStage = ''
  over.listingId = ''
  over.stage = ''
}

function onDragEnter(listingId, stage) {
  if (!drag.rowId) return
  if (drag.listingId !== listingId) return
  over.listingId = listingId
  over.stage = stage
}

function onDragLeave(listingId, stage) {
  if (over.listingId === listingId && over.stage === stage) {
    over.listingId = ''
    over.stage = ''
  }
}

function onDrop(listingId, stage) {
  if (!drag.rowId) return
  if (drag.listingId !== listingId) return
  if (drag.fromStage === stage) return onDragEnd()
  app.moveCandidate(listingId, drag.rowId, stage)
  app.toast = { kind: 'ok', text: `Movido a: ${stage}` }
  onDragEnd()
}

function candidateTitle(selectionRow) {
  const cid = selectionRow?.candidateId
  if (!cid) return ''
  const c = (app.state?.candidates || []).find((x) => x.id === cid)
  const bits = []
  if (c?.title) bits.push(c.title)
  if (c?.location) bits.push(c.location)
  return bits.filter(Boolean).join(' · ')
}

function cvUrlFor(selectionRow) {
  const cid = selectionRow?.candidateId
  if (!cid) return ''
  const c = (app.state?.candidates || []).find((x) => x.id === cid)
  return c?.cvUrl || ''
}

function openCv(selectionRow) {
  const url = cvUrlFor(selectionRow)
  if (!url) return
  window.open(url, '_blank', 'noopener,noreferrer')
}

function openCandidate(selectionRow) {
  // Avoid opening while dragging
  if (drag.rowId) return
  const cid = selectionRow?.candidateId
  if (!cid) return
  app.openCandidateDrawer(cid)
}
</script>

<style scoped>
.accHead {
  width: 100%;
  text-align: left;
  border: 1px solid var(--line);
  background: transparent;
  color: inherit;
  padding: 12px;
  cursor: pointer;
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 10px;
  align-items: start;
}

.accHead:hover {
  border-color: var(--line2);
}

.accBody {
  margin-top: 10px;
}

.cols {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 10px;
}

.col {
  border: 1px solid var(--line);
  background: var(--card2);
  padding: 10px;
}

.col[data-dnd='true'] {
  border-color: var(--line2);
}

.col[data-over='true'] {
  border-color: var(--line2);
  background: color-mix(in oklab, var(--card2) 70%, var(--bg));
}

.cand[data-dragging='true'] {
  opacity: 0.5;
  border-color: var(--line2);
  background: color-mix(in oklab, var(--card) 75%, var(--bg));
}

.colHead {
  font-weight: 650;
  margin-bottom: 10px;
}

.cand {
  border: 1px solid var(--line);
  background: var(--card);
  padding: 8px;
  display: grid;
  gap: 8px;
  cursor: pointer;
}

.dragHandle {
  border: 1px solid var(--line);
  background: transparent;
  color: inherit;
  width: 28px;
  height: 28px;
  display: grid;
  place-items: center;
  cursor: grab;
  user-select: none;
  padding: 0;
}

.dragHandle:active {
  cursor: grabbing;
}

.hand {
  width: 16px;
  height: 16px;
  background-color: currentColor;
  -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='black' d='M7 22q-1.25 0-2.125-.875T4 19v-7.45q0-.35.25-.6t.6-.25q.15 0 .3.05t.25.15l2.1 1.6V4.75q0-.525.363-.888T8.75 3.5q.525 0 .888.363T10 4.75V12h1V3.75q0-.525.363-.888T12.25 2.5q.525 0 .888.363T13.5 3.75V12h1V4.75q0-.525.363-.888T15.75 3.5q.525 0 .888.363T17 4.75V12h1V6.25q0-.525.363-.888T19.25 5q.525 0 .888.363T20.5 6.25V16q0 2.5-1.75 4.25T14.5 22H7Z'/%3E%3C/svg%3E") center/contain no-repeat;
  mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='black' d='M7 22q-1.25 0-2.125-.875T4 19v-7.45q0-.35.25-.6t.6-.25q.15 0 .3.05t.25.15l2.1 1.6V4.75q0-.525.363-.888T8.75 3.5q.525 0 .888.363T10 4.75V12h1V3.75q0-.525.363-.888T12.25 2.5q.525 0 .888.363T13.5 3.75V12h1V4.75q0-.525.363-.888T15.75 3.5q.525 0 .888.363T17 4.75V12h1V6.25q0-.525.363-.888T19.25 5q.525 0 .888.363T20.5 6.25V16q0 2.5-1.75 4.25T14.5 22H7Z'/%3E%3C/svg%3E") center/contain no-repeat;
}

.cand:hover {
  border-color: var(--line2);
}

.cand[data-dragging='true'] {
  opacity: 0.6;
  border-color: var(--line2);
}

.cand .textarea {
  min-height: 68px;
  resize: vertical;
}

.listPanel {
  border: 1px solid var(--line);
  background: transparent;
  padding: 10px;
}

.actionsPanel {
  border: 1px solid var(--line);
  background: transparent;
  padding: 10px;
}

.movePanel {
  margin-top: 10px;
  border-top: 1px solid var(--line);
  padding-top: 10px;
}

.notesPreview {
  width: 100%;
  text-align: left;
  border: 1px solid var(--line);
  background: transparent;
  color: inherit;
  padding: 8px;
}

.notesPreview:hover {
  border-color: var(--line2);
}

@media (max-width: 1100px) {
  .cols {
    grid-template-columns: 1fr;
  }
}
</style>
