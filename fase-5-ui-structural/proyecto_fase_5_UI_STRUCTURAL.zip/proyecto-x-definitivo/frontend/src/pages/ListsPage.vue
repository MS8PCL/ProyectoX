<template>
  <div class="stack">
    <div class="card">
      <div class="row" style="justify-content: space-between; align-items: baseline">
        <div>
          <div style="font-weight: 650">Listas</div>
          <div class="muted" style="font-size: 12px; margin-top: 6px">Base de candidatos para futuras vacantes (no saca del proceso de selección).</div>
        </div>
      </div>
    </div>

    <div v-if="app.role !== 'empresa'" class="card muted">Esta sección es para Empresa.</div>

    <div v-else class="stack">
      <div class="card">
        <div class="row" style="gap: 8px; align-items: center">
          <input class="input" v-model="newListName" placeholder="Nueva lista…" />
          <button class="btn primary" :disabled="!newListName.trim()" @click="create">Crear</button>
        </div>
      </div>

      <div class="grid">
        <div class="card">
          <div class="muted" style="font-size: 12px; margin-bottom: 8px">Listas</div>
          <div class="stack">
            <button v-for="l in app.lists" :key="l.id" class="rowBtn" type="button" :data-active="activeListId === l.id" @click="activeListId = l.id">
              <span>{{ l.name }}</span>
              <span class="kbd">{{ (app.listMembers?.[l.id]?.length || 0) }}</span>
            </button>
            <div v-if="!app.lists.length" class="muted" style="font-size: 12px">(vacío)</div>
          </div>
        </div>

        <div class="card">
          <div class="row" style="justify-content: space-between; align-items: baseline">
            <div style="width: 100%">
              <div class="muted" style="font-size: 12px; margin-bottom: 6px">Nombre de la lista</div>
              <div class="row" style="gap: 8px; align-items: center">
                <input class="input" v-model="rename" :disabled="!activeListId" placeholder="—" />
                <button class="btn" :disabled="!activeListId || !rename.trim()" @click="saveRename">Guardar</button>
              </div>
              <div class="muted" style="font-size: 12px; margin-top: 6px">{{ members.length }} candidatos</div>
            </div>
          </div>

          <div v-if="!activeListId" class="muted" style="font-size: 12px; margin-top: 10px">Selecciona una lista.</div>

          <div v-else class="stack" style="margin-top: 10px">
            <div v-for="c in members" :key="c.id" class="row" style="justify-content: space-between">
              <div>
                <div style="font-weight: 650">{{ c.name }}</div>
                <div class="muted" style="font-size: 12px">{{ c.title || '—' }} · {{ c.location || '—' }}</div>
              </div>
              <div class="row" style="gap: 8px">
                <button class="btn" @click="app.removeCandidateFromList(activeListId, c.id)">Quitar</button>
              </div>
            </div>
            <div v-if="!members.length" class="muted" style="font-size: 12px">(vacío)</div>
          </div>
        </div>
      </div>

      <div class="card muted" style="font-size: 12px">
        Tip: añade candidatos a una lista desde el Proceso de Selección (botón LISTA en cada candidato).
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { useAppStore } from '../stores/app.js'

const app = useAppStore()
app.bootstrap()

const newListName = ref('')
const activeListId = ref('')

watch(
  () => app.lists?.length,
  () => {
    if (!activeListId.value) activeListId.value = app.lists?.[0]?.id || ''
  },
  { immediate: true }
)

const activeList = computed(() => (app.lists || []).find((l) => l.id === activeListId.value) || null)

const rename = ref('')
watch(
  () => activeListId.value,
  () => {
    rename.value = activeList.value?.name || ''
  },
  { immediate: true }
)

function saveRename() {
  if (!activeListId.value) return
  app.renameList(activeListId.value, rename.value)
}

const members = computed(() => {
  const ids = app.listMembers?.[activeListId.value]
  const set = new Set(Array.isArray(ids) ? ids : [])
  return (app.candidates || [])
    .filter((c) => set.has(c.id))
    .slice()
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')))
})

function create() {
  const l = app.createList(newListName.value)
  if (l) {
    activeListId.value = l.id
    newListName.value = ''
  }
}
</script>

<style scoped>
.grid {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 10px;
}

.rowBtn {
  width: 100%;
  text-align: left;
  border: 1px solid var(--line);
  background: transparent;
  color: inherit;
  padding: 10px;
  display: flex;
  justify-content: space-between;
  gap: 10px;
  cursor: pointer;
}

.rowBtn[data-active='true'] {
  border-color: var(--line2);
  background: var(--card2);
}

@media (max-width: 900px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>
