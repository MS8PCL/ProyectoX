<template>
  <div class="stack">
    <header>
      <h1 style="margin:0">Hire Tools (enterprise MVP)</h1>
      <p class="muted" style="margin: 6px 0 0">
        Esta pantalla es “herramientas” para probar RBAC preview + outbox manual export sin depender aún de entidades HR finales.
      </p>
    </header>

    <div class="card">
      <div style="font-weight:650">1) Permission Preview</div>
      <div class="grid" style="margin-top: 10px">
        <label>
          <div class="muted">Hire ID</div>
          <input class="input" v-model="hireId" placeholder="ej: hire_123" />
        </label>
        <label>
          <div class="muted">departmentKey</div>
          <input class="input" v-model="inputs.departmentKey" placeholder="DEPT_FIN" />
        </label>
        <label>
          <div class="muted">jobTitleKey</div>
          <input class="input" v-model="inputs.jobTitleKey" placeholder="JT_ANALYST" />
        </label>
        <label>
          <div class="muted">costCenterKey</div>
          <input class="input" v-model="inputs.costCenterKey" placeholder="CC_001" />
        </label>
      </div>
      <div class="row" style="gap: 10px; margin-top: 10px">
        <button class="btn" @click="generatePreview">Generar preview</button>
        <button class="btn" @click="loadPreview">Cargar preview vigente</button>
      </div>
      <pre v-if="preview" class="pre" style="margin-top:10px">{{ pretty(preview) }}</pre>
    </div>

    <div class="card">
      <div style="font-weight:650">2) Outbox manual export</div>
      <div class="grid" style="margin-top: 10px">
        <label>
          <div class="muted">workflowInstanceId (opcional)</div>
          <input class="input" v-model="workflowInstanceId" placeholder="wf_inst_id" />
        </label>
      </div>
      <div class="row" style="gap: 10px; margin-top: 10px">
        <button class="btn" @click="enqueueOutbox">Enqueue otrs_create_ticket</button>
        <button class="btn" @click="simulateTicket">Mock simulate ticket (crea/avanza)</button>
      </div>
      <pre v-if="outbox" class="pre" style="margin-top:10px">{{ pretty(outbox) }}</pre>
      <pre v-if="ticket" class="pre" style="margin-top:10px">{{ pretty(ticket) }}</pre>
    </div>

    <div v-if="error" class="card" style="border-color: color-mix(in oklab, var(--danger) 50%, var(--line))">
      <div class="mono">{{ error }}</div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { api } from '../lib/api'

const hireId = ref('hire_demo_1')
const workflowInstanceId = ref('')
const inputs = ref({ departmentKey: 'DEPT_FIN', jobTitleKey: 'JT_ANALYST', costCenterKey: 'CC_001' })

const preview = ref(null)
const outbox = ref(null)
const ticket = ref(null)
const error = ref('')

function pretty(obj) {
  return JSON.stringify(obj, null, 2)
}

async function generatePreview() {
  error.value = ''
  preview.value = null
  try {
    const res = await api('/rbac/preview', {
      method: 'POST',
      body: JSON.stringify({ entityType: 'hire', entityId: hireId.value, inputs: inputs.value, workflowInstanceId: workflowInstanceId.value || undefined }),
    })
    preview.value = res.preview
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

async function loadPreview() {
  error.value = ''
  preview.value = null
  try {
    const res = await api(`/rbac/preview/${encodeURIComponent(hireId.value)}`)
    preview.value = res.preview
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

async function enqueueOutbox() {
  error.value = ''
  outbox.value = null
  try {
    if (!workflowInstanceId.value) {
      throw new Error('Necesitas workflowInstanceId para pinning (crea una workflow_instance primero).')
    }
    const res = await api('/outbox/enqueue/otrs_create_ticket', {
      method: 'POST',
      body: JSON.stringify({ entityType: 'hire', entityId: hireId.value, workflowInstanceId: workflowInstanceId.value }),
    })
    outbox.value = res.outbox
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

async function simulateTicket() {
  error.value = ''
  ticket.value = null
  try {
    const res = await api(`/mock/otrs/simulate/${encodeURIComponent(hireId.value)}`, { method: 'POST', body: JSON.stringify({}) })
    ticket.value = res.link
  } catch (e) {
    error.value = String(e?.message || e)
  }
}
</script>

<style scoped>
.stack { display: grid; gap: 16px; }
.grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
.input { width: 100%; border: 1px solid var(--line); background: var(--card); color: inherit; padding: 8px 10px; }
.pre { margin: 0; padding: 10px; border: 1px solid var(--line); background: var(--card2); overflow: auto; max-height: 420px; }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
@media (max-width: 900px) { .grid { grid-template-columns: 1fr; } }
</style>
