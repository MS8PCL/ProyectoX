<template>
  <div class="stack">
    <header class="row" style="justify-content: space-between; align-items: end">
      <div>
        <h1 style="margin: 0">Outbox (enterprise)</h1>
        <p class="muted" style="margin: 6px 0 0">Modo manual export / mock. No hay API OTRS real.</p>
      </div>
      <div class="row" style="gap: 10px">
        <label class="muted">Status</label>
        <select class="input" v-model="status">
          <option value="">(todos)</option>
          <option value="pending">pending</option>
          <option value="exported_manually">exported_manually</option>
          <option value="failed">failed</option>
        </select>
        <button class="btn" @click="load">Recargar</button>
      </div>
    </header>

    <div class="card">
      <div class="row" style="justify-content: space-between">
        <span class="muted">Items</span>
        <span class="kbd">{{ items.length }}</span>
      </div>

      <div class="list" style="margin-top: 10px">
        <div v-for="it in items" :key="it.id" class="item">
          <div class="row" style="justify-content: space-between">
            <div>
              <div style="font-weight: 650">{{ it.kind }}</div>
              <div class="muted mono">{{ it.entity_type }}:{{ it.entity_id }} · status={{ it.status }}</div>
              <div class="muted mono">idem={{ it.idempotency_key }}</div>
            </div>
            <button class="btn" @click="openExport(it)">Export</button>
          </div>
        </div>
      </div>
    </div>

    <div v-if="exportItem" class="card">
      <div class="row" style="justify-content: space-between">
        <div>
          <div style="font-weight: 650">Export payload</div>
          <div class="muted mono">outbox={{ exportItem.id }}</div>
        </div>
        <div class="row" style="gap: 10px">
          <button class="btn" @click="markExported(exportItem)">Mark exported</button>
          <button class="btn" @click="exportItem = null">Cerrar</button>
        </div>
      </div>

      <pre class="pre" style="margin-top: 10px">{{ pretty(exportBlob) }}</pre>
    </div>

    <div v-if="error" class="card" style="border-color: color-mix(in oklab, var(--danger) 50%, var(--line))">
      <div class="mono">{{ error }}</div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { api } from '../lib/api'

const status = ref('')
const items = ref([])
const error = ref('')

const exportItem = ref(null)
const exportBlob = ref(null)

function pretty(obj) {
  return JSON.stringify(obj, null, 2)
}

async function load() {
  error.value = ''
  try {
    const qs = status.value ? `?status=${encodeURIComponent(status.value)}` : ''
    const res = await api(`/enterprise/outbox${qs}`)
    items.value = res.items || []
  } catch (e) {
    const msg = String(e?.message || e)
    error.value = msg
    // If cookie/session expired but UI still thinks it's logged in, force user back to login.
    if (msg.startsWith('API 401:')) {
      const next = encodeURIComponent('/interno/altas')
      window.location.href = `/login?next=${next}`
    }
  }
}

async function openExport(it) {
  error.value = ''
  exportItem.value = it
  exportBlob.value = null
  try {
    const res = await api(`/outbox/${it.id}/export`)
    exportBlob.value = res.export
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

async function markExported(it) {
  error.value = ''
  try {
    await api(`/outbox/${it.id}/mark_exported`, { method: 'POST', body: JSON.stringify({}) })
    await load()
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

onMounted(load)
</script>

<style scoped>
.stack { display: grid; gap: 16px; }
.input { border: 1px solid var(--line); background: var(--card); color: inherit; padding: 8px 10px; }
.list { display: grid; gap: 10px; }
.item { border: 1px solid var(--line); background: var(--card2); padding: 12px; }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.pre { margin: 0; padding: 10px; border: 1px solid var(--line); background: var(--card2); overflow: auto; max-height: 420px; }
</style>
