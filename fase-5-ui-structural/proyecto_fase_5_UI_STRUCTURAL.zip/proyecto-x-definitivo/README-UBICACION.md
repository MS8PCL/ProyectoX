# Proyecto X — Ubicación de trabajo

Esta carpeta es la **ubicación recomendada** para trabajar con Proyecto X.

Motivo: el workspace original está bajo una ruta que contiene `C:\Users\...` en el nombre (por compatibilidad de OpenClaw), y algunas herramientas (Vite/Node ESM) fallan con rutas con `:` y `\`.

## Cómo arrancar

```bash
cd /Users/manuserrano/openclaw_projects/proyecto-x
npm install
npm run dev
```

## Origen

Copiado desde:
`/Users/manuserrano/C:\Users\Manu\.openclaw\workspace/proyecto-x`

**Nota:** No se copia `node_modules`.
