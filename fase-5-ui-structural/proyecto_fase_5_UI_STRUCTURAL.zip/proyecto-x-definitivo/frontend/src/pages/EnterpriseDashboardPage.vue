<template>
  <div class="stack">
    <header class="row" style="justify-content: space-between; align-items: end">
      <div>
        <h1 style="margin: 0">Dashboard HR→IT (MVP)</h1>
        <p class="muted" style="margin: 6px 0 0">Vista mínima: outbox pendientes + nota. Workflow state board: siguiente iteración.</p>
      </div>
      <button class="btn" @click="load">Recargar</button>
    </header>

    <div class="grid">
      <div class="card">
        <div class="row" style="justify-content: space-between">
          <span class="muted">Outbox pending</span>
          <span class="kbd">{{ outboxPending.length }}</span>
        </div>
        <div style="margin-top: 10px" class="list">
          <div v-for="it in outboxPending" :key="it.id" class="row" style="justify-content: space-between">
            <span class="mono">{{ it.kind }} · {{ it.entity_id }}</span>
            <RouterLink class="muted" to="/enterprise/outbox">ver</RouterLink>
          </div>
        </div>
      </div>

      <div class="card">
        <div style="font-weight:650">Siguientes</div>
        <p class="muted" style="margin: 8px 0 0">
          Próximo commit: board por workflow state + métricas (lead time) leyendo workflow_instances + workflow_event_log.
        </p>
      </div>
    </div>

    <div v-if="error" class="card" style="border-color: color-mix(in oklab, var(--danger) 50%, var(--line))">
      <div class="mono">{{ error }}</div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { api } from '../lib/api'

const error = ref('')
const outboxPending = ref([])

async function load() {
  error.value = ''
  try {
    const res = await api('/enterprise/outbox?status=pending')
    outboxPending.value = res.items || []
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

onMounted(load)
</script>

<style scoped>
.stack { display: grid; gap: 16px; }
.grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.list { display: grid; gap: 6px; }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
@media (max-width: 900px) { .grid { grid-template-columns: 1fr; } }
</style>
