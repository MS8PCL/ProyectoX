<template>
  <div class="stack">
    <header class="row" style="justify-content: space-between; align-items: end">
      <div>
        <h1 style="margin: 0">RBAC rules (enterprise)</h1>
        <p class="muted" style="margin: 6px 0 0">Vista mínima: lista + condición + perfiles resultantes.</p>
      </div>
      <button class="btn" @click="load">Recargar</button>
    </header>

    <div class="card">
      <div class="row" style="justify-content: space-between">
        <span class="muted">Rules</span>
        <span class="kbd">{{ rules.length }}</span>
      </div>

      <div class="list" style="margin-top: 10px">
        <div v-for="r in rules" :key="r.id" class="rule">
          <div class="row" style="justify-content: space-between">
            <div>
              <div style="font-weight: 650">{{ r.name }}</div>
              <div class="muted mono">prio={{ r.priority }} · status={{ r.status }}</div>
            </div>
            <div class="mono muted">{{ r.id }}</div>
          </div>
          <details style="margin-top: 10px">
            <summary class="muted">Condition / Result</summary>
            <pre class="pre">{{ pretty({ condition: r.condition, result_access_profiles: r.result_access_profiles }) }}</pre>
          </details>
        </div>
      </div>
    </div>

    <div v-if="error" class="card" style="border-color: color-mix(in oklab, var(--danger) 50%, var(--line))">
      <div class="mono">{{ error }}</div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { api } from '../lib/api'

const rules = ref([])
const error = ref('')

function pretty(obj) {
  return JSON.stringify(obj, null, 2)
}

async function load() {
  error.value = ''
  try {
    const res = await api('/enterprise/rbac/rules')
    rules.value = res.items || []
  } catch (e) {
    error.value = String(e?.message || e)
  }
}

onMounted(load)
</script>

<style scoped>
.stack { display: grid; gap: 16px; }
.list { display: grid; gap: 10px; }
.rule { border: 1px solid var(--line); background: var(--card2); padding: 12px; }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.pre { margin: 10px 0 0; padding: 10px; border: 1px solid var(--line); background: var(--card); overflow: auto; }
</style>
