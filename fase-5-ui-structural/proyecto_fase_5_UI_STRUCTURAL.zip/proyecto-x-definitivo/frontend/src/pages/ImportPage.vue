<template>
  <div class="stack">
    <div class="card">
      <div style="font-weight: 650">Importar</div>
      <div class="muted" style="font-size: 12px; margin-top: 6px">
        Pega JSON del state (o { state: ... }). Se normaliza.
      </div>
    </div>

    <div class="card stack">
      <textarea class="textarea" rows="14" v-model="text" placeholder="{ ... }" />

      <div class="row" style="justify-content: space-between">
        <div class="muted" style="font-size: 12px">
          Consejo: usa Datos → Exportar para generar un ejemplo.
        </div>
        <div class="row" style="gap: 8px">
          <button class="btn" @click="preview">Preview</button>
          <button class="btn primary" @click="doImport">Importar</button>
        </div>
      </div>

      <div v-if="err" class="card" style="border-color: color-mix(in oklab, var(--danger) 50%, var(--line))">
        <div style="font-weight: 650">Error</div>
        <div class="muted" style="margin-top: 6px; white-space: pre-wrap">{{ err }}</div>
      </div>

      <div v-if="info" class="card">
        <div style="font-weight: 650">Preview</div>
        <div class="muted" style="margin-top: 6px; white-space: pre-wrap">{{ info }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useAppStore } from '../stores/app.js'

const app = useAppStore()
app.bootstrap()

const text = ref('')
const err = ref('')
const info = ref('')

function preview() {
  err.value = ''
  info.value = ''
  try {
    const data = JSON.parse(text.value)
    const s = data?.state && typeof data.state === 'object' ? data.state : data
    const listings = Array.isArray(s?.listings) ? s.listings.length : 0
    const favorites = Array.isArray(s?.favorites) ? s.favorites.length : 0
    info.value = `listings: ${listings}\nfavorites: ${favorites}\ntheme: ${s?.theme}\nrole: ${s?.role}`
  } catch (e) {
    err.value = e?.message || String(e)
  }
}

function doImport() {
  err.value = ''
  info.value = ''
  try {
    app.importStateFromJsonText(text.value)
    app.toast = { kind: 'ok', text: 'Import OK.' }
  } catch (e) {
    err.value = e?.message || String(e)
  }
}
</script>
