<template>
  <div class="stack">
    <div class="card">
      <div style="font-weight: 650">Datos</div>
      <div class="muted" style="font-size: 12px; margin-top: 6px">
        Export/Reset. (Import está en su sección).
      </div>
    </div>

    <div class="card stack">
      <div class="row" style="justify-content: space-between">
        <div>
          <div style="font-weight: 650">Export</div>
          <div class="muted" style="font-size: 12px">Descarga el state actual.</div>
        </div>
        <button class="btn" @click="exportNow">Exportar JSON</button>
      </div>

      <hr class="sep" />

      <div class="row" style="justify-content: space-between">
        <div>
          <div style="font-weight: 650">Reset</div>
          <div class="muted" style="font-size: 12px">Borra los datos locales del navegador.</div>
        </div>
        <button class="btn danger" @click="reset">Reset</button>
      </div>

      <hr class="sep" />

      <details class="card" style="background: var(--card2)">
        <summary>Ver state (debug)</summary>
        <pre style="margin: 10px 0 0; font-size: 12px; white-space: pre-wrap">{{ json }}</pre>
      </details>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useAppStore } from '../stores/app.js'
import { downloadJson, resetState } from '../lib/storage.js'

const app = useAppStore()
app.bootstrap()

const json = computed(() => JSON.stringify(app.state, null, 2))

function exportNow() {
  downloadJson('proyecto-x-state.json', { state: app.state })
}

function reset() {
  if (!confirm('Reset localStorage?')) return
  resetState()
  window.location.reload()
}
</script>
